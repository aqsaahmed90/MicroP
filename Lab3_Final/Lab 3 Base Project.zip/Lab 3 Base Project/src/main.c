#include "main.h"
int ticks = 0;
int tapFlag = 0;
double OffX = 0.0139, OffY = -0.0257, OffZ = -0.032;
volatile int i;
	int n = 1;
	int brightness = 0;
	
/* Delayer ------------------------------------------------------------------*/
void Delay(uint32_t delay) {
  for(i=0;i<delay;i++); 
}


void pwm(){

	 while(1)  // Do not exit
  {
    if (((brightness + n) >= 1000) || ((brightness + n) <= 0))
      n = -n; // if  brightness maximum/maximum change direction
 
        brightness += n;
 
    TIM4->CCR1 = brightness; // set brightness
    TIM4->CCR2 = brightness; // set 
		TIM4->CCR3 = brightness; // set brightness
		TIM4->CCR4 = brightness; // set brightness
 
    Delay(10000);								  // delay
		if(!tapFlag){
			printf("switch to acc\n");
			break;
		}
  }
}

void accReader(){
	int32_t delayP=0, delayR=0;
	int32_t out[3];
	double x,y,z;
	double pitch, roll;
	double bufferValsX[FILTER_DEPTH] = {0};
	double bufferValsY[FILTER_DEPTH] = {0};
	double bufferValsZ[FILTER_DEPTH] = {0};
	
	struct movingAvgFilter filterX = {FILTER_DEPTH,1,0};
	struct movingAvgFilter filterY = {FILTER_DEPTH,1,0};
	struct movingAvgFilter filterZ = {FILTER_DEPTH,1,0};
	
	while(1){
		
		// Wait for an interrupt
		while(!ticks);
		// Decrement ticks
		ticks = 0;
		
		LIS302DL_ReadACC(out);
	
		movingFilter(out[0],bufferValsX,&filterX);
		movingFilter(out[1],bufferValsY,&filterY);
 		movingFilter(out[2],bufferValsZ,&filterZ);		
 		
		x = ((filterX.average)*MILLI)- OffX;
		y = ((filterY.average)*MILLI)- OffY;
 		z = ((filterZ.average)*MILLI)- OffZ;
		
//		printf("x: %f\n",x);
// 		printf("y: %f\n",y);
// 		printf("z: %f\n",z);
		
		pitch	= atan((x)/(sqrt((y*y)+(z*z))))*DEGREE;
		roll 	= atan((y)/(sqrt((x*x)+(z*z))))*DEGREE;
 		printf("pitch: %f\n",pitch);
 		printf("roll : %f\n",roll);
		
#ifdef SHOW_LED		
		if(pitch >= -90 && pitch <-45)			delayP = 1250000;
		else if(pitch >= -45 && pitch <0)		delayP = 625000;
		else if(pitch >= 0 && pitch <45)	  delayP = 312500 ;
		else if(pitch >= 45 && pitch <90)	  delayP = 156250;


		
		if(roll >= -90 && roll <-45)			delayR = 1250000;
		else if(roll >= -45 && roll <0)		delayR = 625000;
		else if(roll >= 0 && roll <45)	  delayR = 312500;
		else if(roll >= 45 && roll <90)	  delayR = 156250;

		GPIO_ToggleBits(GPIOD,LED2); 	// toggle LED
		Delay(delayP);		 									// wait a short period of time
		GPIO_ToggleBits(GPIOD,LED2); 	// toggle LED
		Delay(delayP);
		
		GPIO_ToggleBits(GPIOD,LED1); 	// toggle LED
		Delay(delayR);		 									// wait a short period of time
		GPIO_ToggleBits(GPIOD,LED1); 	// toggle LED
		Delay(delayR);
#endif					
		if(tapFlag){
			printf("switch to pwm\n");
			break;
		}
	}
}

int main()
{
	INTTIM_Config();
//	configLED();
//	pwmInit();
	AccelInit();
	
	while(1){
		if (!tapFlag){
			configLED();
			GPIOD->BSRRH = LED_ALL;
			printf("readings\n");
			accReader();
		}
		else{
			configLED();
			pwmInit();
			printf("pwming\n");
			pwm();
		}
			
	}
	
}
void EXTI0_IRQHandler ()
{
	if (EXTI_GetFlagStatus(EXTI_Line0) != RESET)
  {
    EXTI_ClearITPendingBit(EXTI_Line0);
// 		printf("EXT IRQ\n");
		tapFlag = !tapFlag;
  }
}
void TIM3_IRQHandler(void)
{
  if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
  {
    TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
		ticks = 1;
  }
}
