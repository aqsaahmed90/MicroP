#include "stm32f4_discovery_lis302dl.h"
#include "stm32f4xx.h"

void AccelInit(void);
void INTTIM_Config(void);
void pwmInit(void);
